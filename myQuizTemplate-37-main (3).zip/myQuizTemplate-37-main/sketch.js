var canva;

function setup(){
  canvas = createCanvas(850,400);
}


function draw(){
  background("pink");

  
}
